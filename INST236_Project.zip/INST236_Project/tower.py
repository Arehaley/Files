import pygame
import math

"""
Represents a tower object in the game.

This class is responsible for creating and updating tower objects in the game. Towers have a range within which they can attack enemies. When updated, 
towers check the distance to each enemy and attack enemies within range by reducing their health.
"""

class Tower:
    def __init__(self, image, x, y,health):
        """
        Initializes the tower object.

        Parameters:
        - image (Surface): The image for the tower.
        - x (int): The x-coordinate for the tower's position.
        - y (int): The y-coordinate for the tower's position.
        - health (int): The health of the tower.
        """
        # Initilizes tower properties 
        self.range = 50
        self.health = health
        self.x = x
        self.y = y
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y) 



    def update(self, enemy_group,current_frame):
        """
        Updates the tower object, attacking enemies within range.

        Parameters:
        - enemy_group (Group): The group containing all enemy objects.
        - current_frame (list): The list of all current frame objects.
        """
        # Checks if tower has died, if so it removes it from the frame
        if self.health <= 0:
            current_frame.remove(self)

        # Check distance to each enemy to see if it is in range
        for enemy in enemy_group:
            if enemy.health > 0:
                # Calculate distances
                x_dist = enemy.pos[0] - self.x
                y_dist = enemy.pos[1] - self.y
                dist = math.sqrt(x_dist ** 2 + y_dist ** 2)
                # Check if the enemy is in range
                if dist < self.range:
                    # Reduce enemy health and break the loop
                    enemy.health -= 1
                    self.health -= 1
                    break
