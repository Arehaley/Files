import main as m   
import pygame
import pytest

"""
Unit tests for the game functionality.
This module contains unit tests to verify the initialization and functionality of the game.
The tests include checking the initialization of the game instance, as well as the functions
related to tank hitboxes.

"""

@pytest.fixture
def game_instance(mocker):
    """
    Fixture to create a game instance for testing.
    This fixture creates an instance of the Game class for testing purposes.

    Parameters:
    - mocker: The pytest mocker fixture for mocking objects.

    Returns:
    - Game: An instance of the Game class.
    """
    game = m.Game()
    return game

def test_initialization(game_instance):
    """
    Test the initialization of the game instance.
    This test verifies that the game instance is initialized with the correct attributes and values.

    Parameters:
    - game_instance: The game instance created for testing.
    """
    assert game_instance.screen_width == 700
    assert game_instance.screen_height == 600
    assert game_instance.gameover == True
    assert game_instance.starting == True
    assert len(game_instance.current_frame) == 0
    assert len(game_instance.enemy_group.sprites()) == 0
    assert game_instance.last_enemy_spawn_time == 0
    assert game_instance.waypoints == [
        (0, 100),
        (450, 100),
        (450, 450),
        (330, 445),
        (330,220),
        (100,220),
        (100,400),
        (225,410),
        (225,600)
    ]

def test_game_functions():
    """
    Test the game functions related to tank hitboxes.
    This test verifies the functionality of the functions related to tank hitboxes,
    including clicked_basic_tank and clicked_red_tank.
    """
    # Checks tank hitboxes
    assert m.clicked_basic_tank((0,0)) == False, \
    ("clicked_basic_tank(0,0) returned"
     " unexpeted result") 
    assert m.clicked_basic_tank((650,250)) == True, \
    ("clicked_basic_tank(650,250) returned"
     " unexpeted result") 

    assert m.clicked_red_tank((0,0)) == False, \
    ("clicked_red_tank(0,0) returned"
     " unexpeted result") 
    assert m.clicked_red_tank((650,400)) == True, \
    ("clicked_red_tank(650,400) returned"
     " unexpeted result")  
   

if __name__ == "__main__":
    pytest.main()