import pygame
import variables as v

"""
Represents a background object in the game.

This class is responsible for creating and updating background objects in the game. It loads the image specified by the image_path and positions
it at the given coordinates (x, y). Additionally, it tracks the time of creation and whether the object is temporary.
"""


class Background:
    def __init__(self, image, x, y, time_of_creation=0, temporary=False):
        """
        Initializes the background object.

        Parameters:
        - image_path (str): The path to the image file for the background object.
        - x (int): The x-coordinate for the background object.
        - y (int): The y-coordinate for the background object.
        - time_of_creation (int): The time at which the object was created (default is 0).
        - temporary (bool): Whether the object is temporary (default is False).
        """

        self.image = image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        v.TOC = time_of_creation # Stores when object was created 
        v.TEMP = temporary # Stores whther or object is a temporary object 

    def update(self,current_time):
        """
        Updates the background object.

        Removes the object if it is temporary and the specified duration has elapsed.

        Parameters:
        - current_time (int): The current time in milliseconds.
        """
        if v.TEMP == True: # Checks if temp 
            if ((v.TOC + 100) < current_time) &(v.REMOVE == True): # Removes object after set amount of time 
                self.current_frame.remove(self.temp)
                v.REMOVE = False
        
        


