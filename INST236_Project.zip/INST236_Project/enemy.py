import pygame as pg
from pygame.math import Vector2
import math
import variables as v

"""
Represents an enemy object in the game.

This class is responsible for creating and updating enemy objects in the game. 
Enemies follow a path defined by waypoints and move towards their target. If an enemy reaches the end of the path, 
the player loses health. Enemies have health and take damage as they move along the path if near a tank. If an enemy's health reaches zero,
the player earns points and the enemy is removed from the game. 
 """

class Enemy(pg.sprite.Sprite):
  def __init__(self, waypoints, image, speed):
        """
        Initializes the enemy object.

        Parameters:
        - waypoints (list of tuples): The waypoints defining the path for the enemy.
        - image (Surface): The image surface for the enemy.
        """
        #Sets enemy's orientation and position 
        pg.sprite.Sprite.__init__(self)
        self.waypoints = waypoints
        self.pos = Vector2(self.waypoints[0])
        self.target_waypoint = 1
        self.speed = speed
        self.angle = 0
        self.original_image = image
        self.image = pg.transform.rotate(self.original_image, self.angle)
        self.rect = self.image.get_rect()
        self.rect.center = self.pos
        self.health = 1

  def update(self):
        """
        Updates the enemy object.
        """
        self.move()

  def move(self):
        """
        Moves the enemy along the predefined path towards the target waypoint.
        """
        #define a target waypoint
        if self.target_waypoint < len(self.waypoints):
          self.target = Vector2(self.waypoints[self.target_waypoint])
          self.movement = self.target - self.pos
        else:
          #enemy has reached the end of the path
          v.HEALTH -= 1
          self.kill()  

        if self.health <= 0:
          #enemy takes damage 
          v.POINTS += 2
          if v.ENEMY_SPAWN_INT > 200:
            v.ENEMY_SPAWN_INT -= 10
          self.kill()

        #calculate distance to target
        dist = self.movement.length()
        #check if remaining distance is greater than the enemy speed
        if dist >= self.speed:
          self.pos += self.movement.normalize() * self.speed
        else:
          if dist != 0:
            self.pos += self.movement.normalize() * dist
          self.target_waypoint += 1 

        # Updates rect
        self.rect = self.image.get_rect()
        self.rect.center = self.pos 
