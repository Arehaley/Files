BACKGROUND_POS = (300,300) #Bakcground position
TANK_MENU_POS = (650,250) #Tank menu text position
RED_TANK_MENU_POS = (650,400) #Red Tank menu text position
TEXT_MENU_POS = (610,10) #Menu text position
POINTS = 10 
HEALTH = 10
DAMAGE = 1
ENEMY_SPAWN_INT = 400 # Enemy spawn interval

TOC = 0 # Time of creation, used for red X
TEMP = False # Whether or not a background object is temporary 
REMOVE = True # Whether or not to remove background object