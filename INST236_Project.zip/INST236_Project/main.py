import pygame
import requests 
import re
import random
from tower import Tower as t
from background import Background as b
from enemy import Enemy as e
import variables as v

"""
Represents the main game application.
Initializes the game, handles the game loop, and processes events.

Classes:
- Game: Represents the main game application.

Functions:
- display_text: Displays text on the screen at the specified coordinates.
- clicked_basic_tank: Checks if the basic tank icon is clicked based on the position.
- clicked_red_tank: Checks if the advanced tank icon is clicked based on the position.
- draw_gui: Draws the graphical user interface elements.
- game_end_text: Displays the winning or losing message.
- main: Initializes and runs the game.
- date_time: Retrieves and formats the current date and time.
- quote: Retrieves a random motivational quote.
"""

class Game:
    def __init__(self):
        """
        Initializes the game by setting up the screen, clock, and initial variables.
        """
        # Sets up screen and clock 
        pygame.init()
        self.screen_width = 700
        self.screen_height = 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Game")
        self.clock = pygame.time.Clock()
        self.current_frame = [] 
        self.gameover = True 
        self.starting = True

        # Create the sprite group for enemies
        self.enemy_group = pygame.sprite.Group()

        # Initialize variables for tracking time
        self.last_enemy_spawn_time = 0
        self.last_enemy_spawn_time_two = 0

        # Initializes waypoints 
        self.waypoints = [
        (0, 100),
        (450, 100),
        (450, 450),
        (330, 445),
        (330,220),
        (100,220),
        (100,400),
        (225,410),
        (225,600)
        ] 

        # Set date and time
        self.date_time = date_time()


    def run(self):
        """
        Runs the main game loop, handling events, updating game state, and rendering.
        """
        running = True # Game is running
        clicked_pos = (0,0) # Last clicked position 

        #load images
        backgroud_image = pygame.image.load('images/TowerDefenseBackground.png').convert_alpha()
        x_image = pygame.image.load('images/RedX.png').convert_alpha() 
        enemy_image = pygame.image.load('images/Slime.png').convert_alpha() 
        enemy_image_two = pygame.image.load('images/Slime2.png').convert_alpha()
        self.tank_image = pygame.image.load('images/Tank.png').convert_alpha()
        self.red_tank_image = pygame.image.load('images/RedTank.png').convert_alpha() 

        # Adds background image to frame
        self.current_frame.append(b(backgroud_image, v.BACKGROUND_POS[0], v.BACKGROUND_POS[1]))

        # Starting Screen
        pygame.draw.rect(self.screen, (0, 50, 0), ((0, 80), (700, 270))) # Green Rectangle 
        display_text(self,50,"Welcome to Realm Defense",(255,255,255),0,100,'algerian')
        display_text(self,18,"To win the game reach a score of 50 points by defeating enemies.",(255,255,255),50,175,'algerian')
        display_text(self,18,"If an enemy reaches the path's end 1 health will be lost.",(255,255,255),100,210,'algerian')
        display_text(self,18,"Place tanks infront of enemies to destroy them.",(255,255,255),150,245,'algerian')
        display_text(self,18,"Basic Tanks stop 3 enemies, Advanced stop 12. Click anywhere to begin!",(255,255,255),10,280,'algerian')
        display_text(self,18,("Motivation: "+quote()),(255,255,255),10,540,'algerian') # Motivational Quote

        pause = False # Game not Paused 
        skip = False

        while running: 
            current_time = pygame.time.get_ticks()  # Get current time in milliseconds 
            

            for event in pygame.event.get():
                x, y = pygame.mouse.get_pos() # Current X and Y position

                if event.type == pygame.QUIT: # Quits game if window is closed
                    running = False
                
                # Pause Function
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        if pause == False:
                            self.gameover = True
                            pause = True 
                        else:
                            self.gameover = False
                            skip = True
                            pause = False
                    

                if (event.type == pygame.MOUSEBUTTONDOWN):
                    # Makes it so once the player clicks the start menu the game starts 
                    self.gameover = False 

                    # Checks to see if player clicks within tower hit box and if true allows player to place a tower
                    if (self.gameover == False):
                        if (x < 600):
                            if ((clicked_basic_tank(clicked_pos)) & (v.POINTS >= 5) & (x < 600)):
                                v.POINTS -= 5
                                b_tank = t(self.tank_image, x, y,3)  # Create tank object
                                self.current_frame.append(b_tank)  # Add to current frame

                            if ((clicked_red_tank(clicked_pos)) & (v.POINTS >= 20) & (x < 600)):
                                v.POINTS -= 20
                                r_tank = t(self.red_tank_image, x, y,12)  # Create red tank object
                                self.current_frame.append(r_tank)  # Add to current frame 

                        # Checks to see if clicked in the menu , if so displays red X
                        if (((clicked_basic_tank(clicked_pos)) or (clicked_red_tank(clicked_pos))) & (x > 600)):
                            self.temp = b(x_image, x, y,current_time,True)
                            self.current_frame.append(self.temp) # Adds red X to current frame
                            v.REMOVE = True # Changes remove variable to true
                        
                    clicked_pos = (x,y) # Stores Click 
                     
            # Draws everything on screen once game starts (GAME UPDATE SECTION)
            if (self.gameover == False):
                draw_gui(self) # Draws gui
                
                if current_time - self.last_enemy_spawn_time >= v.ENEMY_SPAWN_INT: # Enemy 1
                   # Create a new enemy object

                    if skip == False: # Pause feature not fully implemented 
                            enemy = e(self.waypoints, enemy_image,random.randint(1,2)) 
                            self.enemy_group.add(enemy)
                    
                    self.last_enemy_spawn_time = current_time + random.randint(0,500)# Reset the last enemy spawn time
                    skip = False 
                   
                if (current_time - self.last_enemy_spawn_time_two >= v.ENEMY_SPAWN_INT) & (v.POINTS > 20): #Enemy 2
                   # Create a new enemy object
                    enemy2 = e(self.waypoints, enemy_image_two,random.randint(4,6))
                    self.enemy_group.add(enemy2)
                   # Reset the last enemy spawn time
                    self.last_enemy_spawn_time_two = current_time + random.randint(0,3000)
                    
                for image in self.current_frame:
                    self.screen.blit(image.image, image.rect) # Responsible for drawing images on screen 

                    if isinstance(image, t): # Updates objects if they are towers 
                        t.update(image,self.enemy_group,self.current_frame)
                    if isinstance(image, b): # Updates background objects 
                        b.update(self,current_time)  


                # Updates and draws enemies 
                self.enemy_group.update()
                self.enemy_group.draw(self.screen) 
                # Health and Points 
                display_text(self,25,("Health: " + str(v.HEALTH)),(255,255,255),v.TEXT_MENU_POS[0],v.TEXT_MENU_POS[1]) #Health
                display_text(self,25,("Points: " + str(v.POINTS)),(255,255,255),v.TEXT_MENU_POS[0],v.TEXT_MENU_POS[1]+25) #Points



            # Checks if won or lost
            if (v.POINTS >= 50):
                game_end_text(self,"You Win")
                self.gameover = True # Game over
            elif(v.HEALTH <=0 ):
                game_end_text(self,"You Lose")
                self.gameover = True # Game over

           # Clock and display
            pygame.display.flip()
            self.clock.tick(60)

        pygame.quit()

def display_text(self,font_size,text,color,x,y,font=None):
    """
    Displays text on the screen at the specified coordinates.
    
    Parameters:
    - font_size (int): Size of the font.
    - text (str): The text to be displayed.
    - color (tuple): The color of the text.
    - x (int): The x-coordinate for the text.
    - y (int): The y-coordinate for the text.
    - font (str): The font type (default is None).
    """
    self.font = pygame.font.SysFont(font, font_size)
    self.screen.blit(self.font.render((text), True, color), (x,y))

def clicked_basic_tank(clicked_pos):
    """
    Checks if the basic tank icon is clicked based on the position.
    
    Parameters:
    - clicked_pos (tuple): The position where the click occurred.
    
    Returns:
    - bool: True if the basic tank icon is clicked, False otherwise.
    """
    tank_x = False
    tank_y = False
    if (clicked_pos[0] > v.TANK_MENU_POS[0]-50) & (clicked_pos[0] < v.TANK_MENU_POS[0]+50): # Checks for x click 
        tank_x = True
    if (clicked_pos[1] < v.TANK_MENU_POS[1]+25) & (clicked_pos[1] > v.TANK_MENU_POS[1]-25): # checks for y click 
        tank_y = True
    if (tank_x & tank_y):
        return True
    else: 
        return False
    
def clicked_red_tank(clicked_pos):
    """
    Checks if the advanced tank icon is clicked based on the position.
    
    Parameters:
    - clicked_pos (tuple): The position where the click occurred.
    
    Returns:
    - bool: True if the advanced tank icon is clicked, False otherwise.
    """
    red_tank_x = False
    red_tank_y = False
    if (clicked_pos[0] > v.RED_TANK_MENU_POS[0]-50) & (clicked_pos[0] < v.RED_TANK_MENU_POS[0]+50): # Checks for x click 
        red_tank_x = True
    if (clicked_pos[1] < v.RED_TANK_MENU_POS[1]+25) & (clicked_pos[1] > v.RED_TANK_MENU_POS[1]-25): # checks for y click 
        red_tank_y = True
    if (red_tank_x & red_tank_y):
        return True
    else:
        return False

def draw_gui(self):
    """
    Draws the graphical user interface elements on the screen.
    
    Parameters:
    - self: The Game instance.
    """
    white = (255,255,255)
    black = (0,0,0)
    pygame.draw.rect(self.screen, (0, 50, 0), ((600, 0), (100, 600))) #Right of screen rectangle
    display_text(self,25,("Basic Tank"),white,v.TEXT_MENU_POS[0],v.TEXT_MENU_POS[1]+190) #Basic Tank
    display_text(self,20,("Price: 5 points"),black,v.TEXT_MENU_POS[0]-5,v.TEXT_MENU_POS[1]+275) #Basic Tank Price
    display_text(self,17,("Advanced Tank"),white,v.TEXT_MENU_POS[0],v.TEXT_MENU_POS[1]+345) #Advanced Tank
    display_text(self,18,("Price: 20 points"),black,v.TEXT_MENU_POS[0]-5,v.TEXT_MENU_POS[1]+425) #Basic Tank
    display_text(self,17,(self.date_time[0]),black,v.TEXT_MENU_POS[0]-5,v.TEXT_MENU_POS[1]+525) #Date
    display_text(self,17,(self.date_time[1]),black,v.TEXT_MENU_POS[0]-5,v.TEXT_MENU_POS[1]+555) #Time
    self.screen.blit(self.tank_image,(v.TANK_MENU_POS[0]-50, v.TANK_MENU_POS[1]-50)) #Basic Tank
    self.screen.blit(self.red_tank_image,(v.RED_TANK_MENU_POS[0]-50, v.RED_TANK_MENU_POS[1]-50)) #Advanced Tank


def game_end_text(self,text):
    """
    Displays the winning or losing message on the screen.
    
    Parameters:
    - self: The Game instance.
    - text (str): The message to be displayed.
    """
    pygame.draw.rect(self.screen, (200, 100, 0), ((0, 150), (700, 200))) # rectangle
    display_text(self,75,(text),(255,255,255),250,200) # Draws ending

def main(): 
    """
    Initializes and runs the game.
    """ 
    window = Game()
    window.run()


def date_time():
    """
    Retrieves and formats the current date and time.
    
    Returns:
    - tuple: A tuple containing the formatted date and time strings.
    """
    # Gets date and time from API
    url = "http://worldtimeapi.org/api/timezone/America/New_York"
    response = requests.get(url)
    rsp = response.json()
    the_time = rsp['datetime']

    groups = re.search(r'(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\.(\d+)',the_time) # Uses regular expression to split time into groups

    # Different time groups
    time_dict = {
        "year" : groups.group(1),
        "month" : groups.group(2),
        "day" : groups.group(3),
        "hour" : groups.group(4),
        "minute" : groups.group(5)
    }
    # Converts 24hr clock to 12hr
    if int(time_dict["hour"]) > 12:
        time_dict['hour'] = str(int(time_dict["hour"]) - 12)

    date = f"Date: {time_dict["month"]}/{time_dict["day"]}/{time_dict["year"]}"
    time = f"Time: {time_dict["hour"]}:{time_dict["minute"]}"
    
    return(date,time) 

def quote():
    """
    Retrieves a random motivational quote.
    
    Returns:
    - str: A random motivational quote.
    """
    quotes = {}
    count = 0
    #Creates dictionary with quotes from file
    with open('motivation.txt', 'r',encoding="utf-8") as f:
        for l in f:
            count+=1
            quotes[count] = l 
    
    rand_quote = quotes[random.randint(1,len(quotes))] # Assigns random quote
    rand_quote = str(rand_quote).strip() #Coverts to string and strips 
    return rand_quote

if __name__ == "__main__":
    main() 
